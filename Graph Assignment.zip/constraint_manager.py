from graph import Graph
from exceptions import InvalidColorError

class ConstraintManager:
    def __init__(self, graph: Graph):
        self.graph = graph

    def set_preassigned_color(self, vertex_id: int, color: int):
        vertex = self.graph.get_vertex(vertex_id)
        vertex.color = color  # This will now raise InvalidColorError if color is invalid

    def add_color_exclusion(self, vertex_id: int, color: int):
        vertex = self.graph.get_vertex(vertex_id)
        vertex.add_excluded_color(color)  # This will now raise InvalidColorError if color is invalid

    def remove_color_exclusion(self, vertex_id: int, color: int):
        vertex = self.graph.get_vertex(vertex_id)
        vertex.remove_excluded_color(color)  # This will now raise InvalidColorError if color is invalid