from typing import Dict, Set
from exceptions import InvalidVertexError, InvalidColorError, InvalidGraphStructureError

class Vertex:
    def __init__(self, id: int):
        if not isinstance(id, int) or id < 0:
            raise InvalidVertexError(f"Vertex ID must be a non-negative integer, got {id}")
        self.id = id
        self._color = None
        self.neighbors = set()
        self.excluded_colors = set()

    @property
    def color(self):
        return self._color

    @color.setter
    def color(self, value):
        if value is not None and (not isinstance(value, int) or value < 0):
            raise InvalidColorError(f"Color must be a non-negative integer or None, got {value}")
        self._color = value

    def add_neighbor(self, neighbor: 'Vertex'):
        if not isinstance(neighbor, Vertex):
            raise InvalidVertexError(f"Neighbor must be a Vertex object, got {type(neighbor)}")
        if neighbor == self:
            raise InvalidGraphStructureError("A vertex cannot be its own neighbor")
        self.neighbors.add(neighbor)
        neighbor.neighbors.add(self)

    def remove_neighbor(self, neighbor: 'Vertex'):
        if not isinstance(neighbor, Vertex):
            raise InvalidVertexError(f"Neighbor must be a Vertex object, got {type(neighbor)}")
        self.neighbors.discard(neighbor)
        neighbor.neighbors.discard(self)

    def add_excluded_color(self, color: int):
        if not isinstance(color, int) or color < 0:
            raise InvalidColorError(f"Excluded color must be a non-negative integer, got {color}")
        self.excluded_colors.add(color)

    def remove_excluded_color(self, color: int):
        if not isinstance(color, int) or color < 0:
            raise InvalidColorError(f"Excluded color must be a non-negative integer, got {color}")
        self.excluded_colors.discard(color)

class Graph:
    def __init__(self):
        self.vertices: Dict[int, Vertex] = {}

    def add_vertex(self, id: int) -> Vertex:
        if not isinstance(id, int) or id < 0:
            raise InvalidVertexError(f"Vertex ID must be a non-negative integer, got {id}")
        if id not in self.vertices:
            self.vertices[id] = Vertex(id)
        return self.vertices[id]

    def remove_vertex(self, id: int):
        if id not in self.vertices:
            raise InvalidVertexError(f"Vertex {id} does not exist in the graph")
        vertex = self.vertices[id]
        for neighbor in list(vertex.neighbors):
            self.remove_edge(id, neighbor.id)
        del self.vertices[id]

    def add_edge(self, id1: int, id2: int):
        if id1 == id2:
            raise InvalidGraphStructureError("Cannot add an edge between a vertex and itself")
        v1 = self.add_vertex(id1)
        v2 = self.add_vertex(id2)
        v1.add_neighbor(v2)

    def remove_edge(self, id1: int, id2: int):
        if id1 not in self.vertices or id2 not in self.vertices:
            raise InvalidVertexError(f"Cannot remove edge: vertex {id1} or {id2} does not exist")
        self.vertices[id1].remove_neighbor(self.vertices[id2])

    def get_vertex(self, id: int) -> Vertex:
        if id not in self.vertices:
            raise InvalidVertexError(f"Vertex {id} does not exist in the graph")
        return self.vertices[id]