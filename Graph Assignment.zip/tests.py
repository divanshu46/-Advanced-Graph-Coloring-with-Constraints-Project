import unittest
import random
import time
from graph import Graph
from coloring_strategies import GreedyColoringStrategy, BacktrackingColoringStrategy, SimulatedAnnealing, GeneticAlgorithm
from coloring_solver import ColoringSolver
from exceptions import InvalidVertexError, InvalidColorError, InvalidGraphStructureError

class TestGraphColoring(unittest.TestCase):
    def setUp(self):
        self.graph = Graph()
        for i in range(5):
            self.graph.add_vertex(i)
        self.graph.add_edge(0, 1)
        self.graph.add_edge(0, 2)
        self.graph.add_edge(1, 2)
        self.graph.add_edge(1, 3)
        self.graph.add_edge(2, 3)
        self.graph.add_edge(3, 4)

    def test_invalid_vertex_creation(self):
        with self.assertRaises(InvalidVertexError):
            self.graph.add_vertex(-1)

    def test_invalid_edge_addition(self):
        with self.assertRaises(InvalidGraphStructureError):
            self.graph.add_edge(0, 0)

    def test_greedy_coloring(self):
        solver = ColoringSolver(self.graph, GreedyColoringStrategy())
        coloring = solver.solve()
        self.assertTrue(all(coloring[v.id] != coloring[n.id] for v in self.graph.vertices.values() for n in v.neighbors))

    def test_backtracking_coloring(self):
        solver = ColoringSolver(self.graph, BacktrackingColoringStrategy())
        coloring = solver.solve()
        self.assertTrue(all(coloring[v.id] != coloring[n.id] for v in self.graph.vertices.values() for n in v.neighbors))

    def test_constraint_handling(self):
        solver = ColoringSolver(self.graph, GreedyColoringStrategy())
        solver.constraint_manager.set_preassigned_color(0, 0)
        solver.constraint_manager.add_color_exclusion(1, 0)
        coloring = solver.solve()
        self.assertEqual(coloring[0], 0)
        self.assertNotEqual(coloring[1], 0)

    def test_dynamic_changes(self):
        solver = ColoringSolver(self.graph, GreedyColoringStrategy())
        initial_coloring = solver.solve()
        changes = [('add_vertex', 5, None), ('add_edge', 4, 5)]
        new_coloring = solver.update_coloring(changes)
        self.assertIn(5, new_coloring)
        self.assertNotEqual(new_coloring[4], new_coloring[5])

    def test_invalid_color_assignment(self):
        with self.assertRaises(InvalidColorError):
            self.graph.get_vertex(0).color = -1

    def test_invalid_color_exclusion(self):
        with self.assertRaises(InvalidColorError):
            self.graph.get_vertex(0).add_excluded_color(-1)
    
    def test_genetic_algorithm(self):
        solver = ColoringSolver(self.graph, GeneticAlgorithm())
        coloring = solver.solve()
        self.assertTrue(all(coloring[v.id] != coloring[n.id] for v in self.graph.vertices.values() for n in v.neighbors))

    def test_simulated_annealing(self):
        solver = ColoringSolver(self.graph, SimulatedAnnealing())
        coloring = solver.solve()
        self.assertTrue(all(coloring[v.id] != coloring[n.id] for v in self.graph.vertices.values() for n in v.neighbors))