from abc import ABC, abstractmethod
from typing import Dict, List, Set
from copy import deepcopy
from graph import Graph, Vertex
from exceptions import GraphColoringError
import random
import math

class ColoringStrategy(ABC):
    @abstractmethod
    def color_graph(self, graph: Graph) -> Dict[int, int]:
        pass

class GreedyColoringStrategy(ColoringStrategy):
    def color_graph(self, graph: Graph) -> Dict[int, int]:
        coloring = {}
        for vertex in graph.vertices.values():
            used_colors = set(coloring.get(neighbor.id) for neighbor in vertex.neighbors if neighbor.id in coloring)
            available_colors = set(range(len(graph.vertices))) - used_colors - vertex.excluded_colors
            if not available_colors:
                raise GraphColoringError(f"No available colors for vertex {vertex.id}")
            coloring[vertex.id] = min(available_colors)
        return coloring

class BacktrackingColoringStrategy(ColoringStrategy):
    def color_graph(self, graph: Graph) -> Dict[int, int]:
        vertices = list(graph.vertices.values())
        num_colors = len(vertices)
        domains = {v.id: set(range(num_colors)) - v.excluded_colors for v in vertices}
        
        def backtrack_with_forward_checking_and_mrv(coloring: Dict[int, int], current_domains: Dict[int, Set[int]]) -> bool:
            if len(coloring) == len(vertices):
                return True
            
            # Select the vertex with the Minimum Remaining Values (MRV)
            unassigned = [v for v in vertices if v.id not in coloring]
            vertex = min(unassigned, key=lambda v: len(current_domains[v.id]))
            
            for color in current_domains[vertex.id]:
                if self.is_safe(vertex, color, coloring):
                    coloring[vertex.id] = color
                    
                    # Forward checking: update domains of unassigned neighbors
                    new_domains = deepcopy(current_domains)
                    if self.update_domains(vertex, color, new_domains):
                        if backtrack_with_forward_checking_and_mrv(coloring, new_domains):
                            return True
                    
                    coloring[vertex.id] = None
            
            return False

        coloring = {}
        if not backtrack_with_forward_checking_and_mrv(coloring, domains):
            raise GraphColoringError("Unable to find a valid coloring")
        return coloring

    def is_safe(self, vertex: Vertex, color: int, coloring: Dict[int, int]) -> bool:
        return all(coloring.get(neighbor.id) != color for neighbor in vertex.neighbors)

    def update_domains(self, vertex: Vertex, color: int, domains: Dict[int, Set[int]]) -> bool:
        for neighbor in vertex.neighbors:
            if neighbor.id not in domains:  # Skip if neighbor is already colored
                continue
            if color in domains[neighbor.id]:
                domains[neighbor.id].remove(color)
                if not domains[neighbor.id]:  # If a domain becomes empty, coloring is impossible
                    return False
        return True

class GeneticAlgorithm(ColoringStrategy):
    def __init__(self, population_size: int = 100, generations: int = 1000, mutation_rate: float = 0.1):
        self.population_size = population_size
        self.generations = generations
        self.mutation_rate = mutation_rate

    def color_graph(self, graph: Graph) -> Dict[int, int]:
        def create_individual():
            return {v: random.randint(0, len(graph.vertices) - 1) for v in graph.vertices}

        def fitness(individual):
            conflicts = sum(1 for v in graph.vertices.values() 
                            for n in v.neighbors 
                            if individual[v.id] == individual[n.id])
            return 1 / (conflicts + 1)

        def crossover(parent1, parent2):
            crossover_point = random.randint(0, len(graph.vertices) - 1)
            child = {**dict(list(parent1.items())[:crossover_point]), 
                     **dict(list(parent2.items())[crossover_point:])}
            return child

        def mutate(individual):
            if random.random() < self.mutation_rate:
                vertex = random.choice(list(graph.vertices.keys()))
                individual[vertex] = random.randint(0, len(graph.vertices) - 1)
            return individual

        population = [create_individual() for _ in range(self.population_size)]

        for _ in range(self.generations):
            population = sorted(population, key=fitness, reverse=True)
            if fitness(population[0]) == 1:
                return population[0]

            new_population = population[:2]  # Elitism

            while len(new_population) < self.population_size:
                parent1, parent2 = random.choices(population[:50], k=2)
                child = crossover(parent1, parent2)
                child = mutate(child)
                new_population.append(child)

            population = new_population

        return max(population, key=fitness)

class SimulatedAnnealing(ColoringStrategy):
    def __init__(self, initial_temperature: float = 100.0, cooling_rate: float = 0.995, iterations: int = 10000):
        self.initial_temperature = initial_temperature
        self.cooling_rate = cooling_rate
        self.iterations = iterations

    def color_graph(self, graph: Graph) -> Dict[int, int]:
        def create_initial_solution():
            return {v: random.randint(0, len(graph.vertices) - 1) for v in graph.vertices}

        def calculate_conflicts(solution):
            return sum(1 for v in graph.vertices.values() 
                       for n in v.neighbors 
                       if solution[v.id] == solution[n.id])

        def generate_neighbor(solution):
            new_solution = solution.copy()
            vertex = random.choice(list(graph.vertices.keys()))
            new_solution[vertex] = random.randint(0, len(graph.vertices) - 1)
            return new_solution

        current_solution = create_initial_solution()
        current_conflicts = calculate_conflicts(current_solution)
        best_solution = current_solution.copy()
        best_conflicts = current_conflicts
        temperature = self.initial_temperature

        for _ in range(self.iterations):
            new_solution = generate_neighbor(current_solution)
            new_conflicts = calculate_conflicts(new_solution)

            if new_conflicts < current_conflicts or random.random() < math.exp((current_conflicts - new_conflicts) / temperature):
                current_solution = new_solution
                current_conflicts = new_conflicts

                if current_conflicts < best_conflicts:
                    best_solution = current_solution.copy()
                    best_conflicts = current_conflicts

                    if best_conflicts == 0:
                        return best_solution

            temperature *= self.cooling_rate

        return best_solution
