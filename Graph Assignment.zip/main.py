import sys
import threading
import time
import random
import traceback
from graph import Graph
from coloring_strategies import GreedyColoringStrategy, BacktrackingColoringStrategy, GeneticAlgorithm, SimulatedAnnealing
from coloring_solver import ColoringSolver
from exceptions import InvalidGraphStructureError

# Increase recursion limit
sys.setrecursionlimit(1000)

class StrategyTimeoutError(Exception):
    """Raised when a strategy execution exceeds the time limit."""
    pass

def run_strategy_with_timeout(solver, timeout=10):
    result = []
    exception = []

    def target():
        try:
            start_time = time.time()
            coloring = solver.solve()
            execution_time = time.time() - start_time
            result.append((coloring, execution_time))
        except Exception as e:
            exception.append(e)

    thread = threading.Thread(target=target)
    thread.start()
    thread.join(timeout)

    if thread.is_alive():
        return None, None  # Indicate timeout without raising an exception

    if exception:
        raise exception[0]
    
    if result:
        return result[0]
    
    raise Exception("Unknown error occurred during strategy execution")

def performance_comparison_test():
    print("Performance Comparison Test: Greedy vs Backtracking vs Genetic Algorithm vs Simulated Annealing")
    print("------------------------------------------------------------------------------------------------")

    timeout = 10  # Set the timeout duration

    for size in [100, 500, 1000, 10000]:
        graph = Graph()
        for i in range(size):
            graph.add_vertex(i)
        for _ in range(size * 2):  # Creating an average of 4 edges per vertex
            v1 = random.randint(0, size-1)
            v2 = random.randint(0, size-1)
            if v1 != v2:
                try:
                    graph.add_edge(v1, v2)
                except InvalidGraphStructureError:
                    pass  # Edge already exists

        strategies = [
            ("Greedy", GreedyColoringStrategy()),
            ("Backtracking", BacktrackingColoringStrategy()),
            ("Genetic Algorithm", GeneticAlgorithm()),
            ("Simulated Annealing", SimulatedAnnealing())
        ]

        print(f"Graph size: {size}")
        for name, strategy in strategies:
            solver = ColoringSolver(graph, strategy)
            try:
                coloring, execution_time = run_strategy_with_timeout(solver, timeout)
                if coloring is None and execution_time is None:
                    print(f"{name}: Strategy execution took more than {timeout} seconds")
                else:
                    print(f"{name} time: {execution_time:.4f} seconds, Colors used: {len(set(coloring.values()))}")
            except Exception as e:
                print(f"{name}: Error - {str(e)}")
                traceback.print_exc()  # Print the full traceback for debugging
        print()

def print_debug_info():
    print(f"Python version: {sys.version}")
    print(f"Recursion limit: {sys.getrecursionlimit()}")
    print(f"Threading active count: {threading.active_count()}")
    print(f"Threading current thread: {threading.current_thread()}")

if __name__ == '__main__':
    print_debug_info()
    performance_comparison_test()
    print("Test completed")