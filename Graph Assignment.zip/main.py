from graph import Graph
from coloring_strategies import GreedyColoringStrategy, BacktrackingColoringStrategy, GeneticAlgorithm, SimulatedAnnealing
from coloring_solver import ColoringSolver
from exceptions import InvalidGraphStructureError
import random
import time
import multiprocessing

class StrategyTimeoutError(Exception):
    """Raised when a strategy execution exceeds the time limit."""
    pass

def run_strategy_with_timeout(solver, result_queue):
    try:
        start_time = time.time()
        coloring = solver.solve()
        execution_time = time.time() - start_time
        result_queue.put((coloring, execution_time))
    except Exception as e:
        result_queue.put((str(e), None))

def run_solver_with_timeout(solver, timeout=5):
    result_queue = multiprocessing.Queue()
    process = multiprocessing.Process(target=run_strategy_with_timeout, args=(solver, result_queue))
    process.start()
    process.join(timeout)
    
    if process.is_alive():
        process.terminate()
        process.join()
        raise StrategyTimeoutError(f"Strategy execution took more than {timeout} seconds")
    
    if not result_queue.empty():
        result = result_queue.get()
        if isinstance(result[0], str):  # It's an error message
            raise Exception(result[0])
        return result
    
    raise Exception("Unknown error occurred during strategy execution")

def performance_comparison_test():
    print("Performance Comparison Test: Greedy vs Backtracking vs Genetic Algorithm vs Simulated Annealing")
    print("------------------------------------------------------------------------------------------------")

    for size in [100, 500, 1000]:
        graph = Graph()
        for i in range(size):
            graph.add_vertex(i)
        for _ in range(size * 2):  # Creating an average of 4 edges per vertex
            v1 = random.randint(0, size-1)
            v2 = random.randint(0, size-1)
            if v1 != v2:
                try:
                    graph.add_edge(v1, v2)
                except InvalidGraphStructureError:
                    pass  # Edge already exists

        strategies = [
            ("Greedy", GreedyColoringStrategy()),
            ("Backtracking", BacktrackingColoringStrategy()),
            ("Genetic Algorithm", GeneticAlgorithm()),
            ("Simulated Annealing", SimulatedAnnealing())
        ]

        print(f"Graph size: {size}")
        for name, strategy in strategies:
            solver = ColoringSolver(graph, strategy)
            try:
                coloring, execution_time = run_solver_with_timeout(solver)
                print(f"{name} time: {execution_time:.4f} seconds, Colors used: {len(set(coloring.values()))}")
            except StrategyTimeoutError as e:
                print(f"{name}: {str(e)}")
            except Exception as e:
                print(f"{name}: Error - {str(e)}")
        print()

if __name__ == '__main__':
    import unittest
    unittest.main(module='tests', exit=False)
    performance_comparison_test()