class GraphColoringError(Exception):
    """Base exception class for graph coloring errors."""
    pass

class InvalidVertexError(GraphColoringError):
    """Raised when an invalid vertex is referenced."""
    pass

class InvalidColorError(GraphColoringError):
    """Raised when an invalid color is used."""
    pass

class InvalidGraphStructureError(GraphColoringError):
    """Raised when the graph structure is invalid."""
    pass