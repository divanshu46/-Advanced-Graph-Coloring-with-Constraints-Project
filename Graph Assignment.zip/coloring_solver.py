from typing import Dict, List, Tuple
from graph import Graph
from coloring_strategies import ColoringStrategy
from constraint_manager import ConstraintManager

class ColoringSolver:
    def __init__(self, graph: Graph, strategy: ColoringStrategy):
        self.graph = graph
        self.strategy = strategy
        self.constraint_manager = ConstraintManager(graph)

    def solve(self) -> Dict[int, int]:
        return self.strategy.color_graph(self.graph)

    def update_coloring(self, changes: List[Tuple[str, int, int]]) -> Dict[int, int]:
        for change_type, vertex_id, data in changes:
            if change_type == 'add_vertex':
                self.graph.add_vertex(vertex_id)
            elif change_type == 'remove_vertex':
                self.graph.remove_vertex(vertex_id)
            elif change_type == 'add_edge':
                self.graph.add_edge(vertex_id, data)
            elif change_type == 'remove_edge':
                self.graph.remove_edge(vertex_id, data)
            else:
                raise ValueError(f"Invalid change type: {change_type}")
        
        return self.solve()